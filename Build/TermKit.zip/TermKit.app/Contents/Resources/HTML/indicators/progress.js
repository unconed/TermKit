(function ($) {
 
/**
 * Controller for progress bar.
 */
var pi = termkit.progress = function (stream) {
  var that = this;

  this.$element = this.$markup();
  this.value = 0;
  this.min = 0;
  this.max = 100;
};

pi.prototype = {
  
  // Return active markup for this field.
  $markup: function () {
    var $progress = $('<div class="termkitProgress">').data('controller', this);
    var that = this;
    return $progress;
  },
  
  updateElement: function () {
    this.$element.empty().progressbar({ value: (this.value - this.min) / (this.max - this.min) * 100 });
  },

};

///////////////////////////////////////////////////////////////////////////////

})(jQuery);
